
Examples: Code Blocks
=====================

The following should render with standard C/C++ highlighting.

.. doxygenfunction:: with_standard_code_block
   :path: ../../examples/specific/code_blocks/xml
   :no-link:

The following should render with no detected highlighting.

.. doxygenfunction:: with_unannotated_cmake_code_block
   :path: ../../examples/specific/code_blocks/xml
   :no-link:

The following should render with specified cmake highlighting.

.. doxygenfunction:: with_annotated_cmake_code_block
   :path: ../../examples/specific/code_blocks/xml
   :no-link:
