/* A dummy interface, which is really just a specially treated class in C++ */

class InterfaceClass
{
};

/*! \interface InterfaceClass interface.h "inc/interface.h"
 *  \brief This is a test interface class.
 *
 * Some details about the InterfaceClass interface
 */
