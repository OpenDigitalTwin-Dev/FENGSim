#include "class.h"

/*! More documentation in the impl file */
void ClassTest::function(int myIntParameter)
{
}

/*! More documentation in the impl file */
void ClassTest::anotherFunction()
{
}

