/*! \brief This is a documentation

This is more documentation.

<h2>Header</h2>
Text

<h2>Header <b>Bold Header Text</b></h2>
Text

Header
---------
Text

### Header ###
Text
*/
class Test {};

