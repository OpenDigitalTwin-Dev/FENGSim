
//! \brief non-namespaced class function
void autoFunction() {};

//! \brief non-namespaced class other function
void anotherAutoFunction() {};
