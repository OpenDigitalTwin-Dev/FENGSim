
/** My function */
int foo(int a[5]);

/** My other function */
int bar(int n, int a[static n]);

