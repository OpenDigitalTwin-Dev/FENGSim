class Thingy;

//! \brief Function that creates a thingy.
auto f_issue_441() -> Thingy*;
