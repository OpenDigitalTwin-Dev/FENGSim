
/*! @file */

/**
 * Foo frob routine.
 * \par bob this something else
 * @sideeffect Frobs any foos.
 * @return Frobs any foos.
 *
 * \par bob this something else
 *
 * @sideeffect Frobs any foos.
 *
 * @param Frobs any foos.
 */
void frob_foos(void* Frobs);

