
/*! \brief first struct inside of namespace

  This is a longer description with a link to a webpage 
  in the text http://www.github.com in order to test out Breathe's
  handling of links.

 */
class Test {};



