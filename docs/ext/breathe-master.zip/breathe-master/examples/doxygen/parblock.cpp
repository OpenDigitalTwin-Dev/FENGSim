/*! \class Test15
 * Normal text.
 *
 * \par A paragraph followed by a paragraph block:
 * \parblock
 * Contents of the first paragraph in the block.
 *
 * New paragraph under the same heading.
 * \endparblock
 *
 * \note
 * This note consists of three paragraphs in a block.
 * \parblock
 * This is the first paragraph in the block.
 *
 * And this is the second paragraph in the block.
 *
 * And still a third paragraph in the block.
 * \endparblock
 *
 * More normal text.
 */
  
class Test15 {};
