#!/usr/bin/env python
# -*- coding: utf-8 -*-

import sys

if __name__ == "__main__":
    from breathe.apidoc import main

    sys.exit(main())
