
Function Warnings
=================

Test 'cannot find project' warning.

.. doxygengroup:: MyFunction
   :project: nonexistent


Test 'cannot find xml' warning:

.. doxygengroup:: MyGroup
   :project: invalidproject


Test 'cannot find function' warning.

.. doxygengroup:: NonExistentGroup
   :project: group


