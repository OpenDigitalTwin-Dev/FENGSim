#include "Vector3.h"


namespace SyntopiaCore {
	namespace Math {	
	}
}

