#define IDI_ICON1                       1
#define IDI_ICON2                       2
