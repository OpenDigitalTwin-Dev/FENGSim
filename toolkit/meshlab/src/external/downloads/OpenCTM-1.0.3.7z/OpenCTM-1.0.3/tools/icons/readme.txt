﻿Copyright information
=====================

Name:    OpenCTM Icon
License: zlib license / by Marcus Geelnard
Icons:   openctm.ico

Name:    Tango Icons
License: Public Domain / by the Tango! Desktop Project
URL:     http://tango.freedesktop.org/Tango_Desktop_Project
Icons:   Document-open.svg
         Document-save.svg
         Help-browser.svg

Name:    Human icons
License: Creative Commons Attribution ShareAlike 2.5 / by the Tango! Desktop Project
URL:     http://tango.freedesktop.org/Tango_Desktop_Project
Icons:   Texture.svg
