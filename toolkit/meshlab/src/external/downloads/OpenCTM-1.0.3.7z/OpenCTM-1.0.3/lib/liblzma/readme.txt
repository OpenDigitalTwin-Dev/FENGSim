This is the C library implementation of LZMA compression/decompression by Igor Pavlov.

Author:  Igor Pavlov
License: Public domain
Version: 4.65 (2009-02-03)

Some administrative adaptations for integration in OpenCTM were made by Marcus Geelnard.
