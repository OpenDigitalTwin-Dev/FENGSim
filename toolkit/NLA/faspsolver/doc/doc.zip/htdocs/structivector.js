var structivector =
[
    [ "row", "structivector.html#a741a152c7b18c401af249dfb3a113c95", null ],
    [ "val", "structivector.html#acd6cc7c196f03f830a22bbba89a6876f", null ]
];