var structprecond__data__sweeping =
[
    [ "A", "structprecond__data__sweeping.html#a6b280014ba3e8512f528c4de783c1bcb", null ],
    [ "Ai", "structprecond__data__sweeping.html#a59f90a564d96e3dbb0e4046580d5e80b", null ],
    [ "local_A", "structprecond__data__sweeping.html#a97ad3a99f4e0599465b9f1889c682071", null ],
    [ "local_index", "structprecond__data__sweeping.html#a3e847f5b4e11ae47560b2b1b23173b63", null ],
    [ "local_LU", "structprecond__data__sweeping.html#a85f78c67c36466243ef6ae098fefacf9", null ],
    [ "NumLayers", "structprecond__data__sweeping.html#a6f1e1ce0a2ef3fbb885783cfb3a7c493", null ],
    [ "r", "structprecond__data__sweeping.html#afc193e8972f36a0f5c4e134825ace77f", null ],
    [ "w", "structprecond__data__sweeping.html#a65a6c7b16e05fbe6ce87e7864ef4b134", null ]
];