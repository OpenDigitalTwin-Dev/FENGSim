var PreMGSolve_8c =
[
    [ "fasp_amg_solve", "PreMGSolve_8c.html#a7fd5d66b6d73e4070c6c94c98ae10612", null ],
    [ "fasp_amg_solve_amli", "PreMGSolve_8c.html#a1664f4ce546856b888dfde0de697c9f1", null ],
    [ "fasp_amg_solve_namli", "PreMGSolve_8c.html#a4019b8955a6d526e79bf400b5ede24c4", null ],
    [ "fasp_famg_solve", "PreMGSolve_8c.html#aea6cd1b4b81eea51f2f92015bccd9cb9", null ]
];