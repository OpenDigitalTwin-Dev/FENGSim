var XtrSamg_8c =
[
    [ "dCSRmat2SAMGInput", "XtrSamg_8c.html#aa5b8bc5d87cae1eebed6828d53e8ccc0", null ],
    [ "dvector2SAMGInput", "XtrSamg_8c.html#a2bbc014a531ed669e3cec20188538a4a", null ]
];