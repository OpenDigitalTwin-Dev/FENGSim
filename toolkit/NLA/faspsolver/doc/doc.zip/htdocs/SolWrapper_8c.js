var SolWrapper_8c =
[
    [ "fasp_fwrapper_dbsr_krylov_amg_", "SolWrapper_8c.html#a7a1bdfb0e25ffe936483967fed9bd0e6", null ],
    [ "fasp_fwrapper_dbsr_krylov_ilu_", "SolWrapper_8c.html#a41c2794916607c0fb28cb5e9cf6222cc", null ],
    [ "fasp_fwrapper_dcsr_amg_", "SolWrapper_8c.html#a37fc15af7f1f7b6800446e93ff5a9c16", null ],
    [ "fasp_fwrapper_dcsr_krylov_amg_", "SolWrapper_8c.html#a63783a0d48b5cc218091b8b4530f8687", null ],
    [ "fasp_fwrapper_dcsr_krylov_ilu_", "SolWrapper_8c.html#a509268f21fd5366471efa5cd316041d9", null ],
    [ "fasp_fwrapper_dcsr_pardiso_", "SolWrapper_8c.html#a85109d175ebe5a923c42ff5ad3305167", null ]
];