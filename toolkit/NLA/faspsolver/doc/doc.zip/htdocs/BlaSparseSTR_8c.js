var BlaSparseSTR_8c =
[
    [ "fasp_dstr_alloc", "BlaSparseSTR_8c.html#ad4b707989f456bc18287571dc954d048", null ],
    [ "fasp_dstr_cp", "BlaSparseSTR_8c.html#af5cced1daa2f3bd4114865caf2b33075", null ],
    [ "fasp_dstr_create", "BlaSparseSTR_8c.html#a02be28c6e1d5310b4fcf142ea462d473", null ],
    [ "fasp_dstr_free", "BlaSparseSTR_8c.html#a78cab1c11aa52e081f6222ef8e4aa59e", null ]
];