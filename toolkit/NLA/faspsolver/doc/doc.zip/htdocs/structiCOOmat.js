var structiCOOmat =
[
    [ "col", "structiCOOmat.html#a35e7c2cd24fb4171cce3d78cd8bb3a23", null ],
    [ "I", "structiCOOmat.html#a18705150686aed6c5e1040c229d11d8c", null ],
    [ "J", "structiCOOmat.html#a236f83c20ce278841fc8ef6e1aacb8e0", null ],
    [ "nnz", "structiCOOmat.html#aa165c73f6701cd01aafc0868e6261dfe", null ],
    [ "row", "structiCOOmat.html#a741a152c7b18c401af249dfb3a113c95", null ],
    [ "val", "structiCOOmat.html#acd6cc7c196f03f830a22bbba89a6876f", null ]
];