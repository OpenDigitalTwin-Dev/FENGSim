var structmxv__matfree =
[
    [ "data", "structmxv__matfree.html#a735984d41155bc1032e09bece8f8d66d", null ],
    [ "fct", "structmxv__matfree.html#ab7e5ed241a6b524d74586f5a57c0c45e", null ]
];