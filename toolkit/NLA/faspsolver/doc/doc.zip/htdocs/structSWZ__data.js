var structSWZ__data =
[
    [ "A", "structSWZ__data.html#a431c2cf84d988c4b841b8805fa63e402", null ],
    [ "al", "structSWZ__data.html#a23e6d35185d17e11948630d4f2691c0f", null ],
    [ "au", "structSWZ__data.html#a768913f17b332a5f11e26dfec5f4fee1", null ],
    [ "blk_data", "structSWZ__data.html#a8bc0efce260b46b9f84c35fdad174191", null ],
    [ "blk_solver", "structSWZ__data.html#aa8bc9d8e9c8d69d74282a5b3054c90ea", null ],
    [ "iblock", "structSWZ__data.html#af5bf0e94a28b0eced9cf2c915e54ab86", null ],
    [ "jblock", "structSWZ__data.html#aaa00603651f68ad44db61778143e65b7", null ],
    [ "mask", "structSWZ__data.html#a06ef238edd833cd958011d0bd71c7817", null ],
    [ "maxa", "structSWZ__data.html#aeaff9bb8aef2889ae3d5768ca37f5106", null ],
    [ "maxbs", "structSWZ__data.html#a1b5dd0b135eb48391796ca1d0a150c5e", null ],
    [ "memt", "structSWZ__data.html#a050caadcd37ff4b65062a38c0ad13f08", null ],
    [ "mumps", "structSWZ__data.html#aaf667526ec4a4a01cd527fffad2e67b3", null ],
    [ "nblk", "structSWZ__data.html#a6e4b56921aa627b117506265c0ec22ab", null ],
    [ "rhsloc", "structSWZ__data.html#abe8149f5bdf25915ddc498b86eaf1522", null ],
    [ "rhsloc1", "structSWZ__data.html#a44cdd12f3b621a6f3520d2f8ce14dc5c", null ],
    [ "SWZ_type", "structSWZ__data.html#a92e5713ae3d8816c3beafa8d70cc755f", null ],
    [ "swzparam", "structSWZ__data.html#a6d794f213dd225ffffebce0ee9db793f", null ],
    [ "xloc1", "structSWZ__data.html#a6774a4ebc40deaf07352694a56300dca", null ]
];