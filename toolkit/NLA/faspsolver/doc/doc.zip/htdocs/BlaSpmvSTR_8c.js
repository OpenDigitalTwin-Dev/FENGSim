var BlaSpmvSTR_8c =
[
    [ "fasp_blas_dstr_aAxpy", "BlaSpmvSTR_8c.html#a196f206b82ae340edc75848b19482e7c", null ],
    [ "fasp_blas_dstr_diagscale", "BlaSpmvSTR_8c.html#a716c933c0c4e67e1945b98e029b9981b", null ],
    [ "fasp_blas_dstr_mxv", "BlaSpmvSTR_8c.html#adc6cfe9c1d89fc5b25c07c60b06f5c03", null ]
];