var structprecond =
[
    [ "data", "structprecond.html#a735984d41155bc1032e09bece8f8d66d", null ],
    [ "fct", "structprecond.html#a7efbe3745748549820a004f62e2ad55c", null ]
];