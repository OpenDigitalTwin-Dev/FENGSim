var structdCOOmat =
[
    [ "col", "structdCOOmat.html#a35e7c2cd24fb4171cce3d78cd8bb3a23", null ],
    [ "colind", "structdCOOmat.html#a308aa24effa77aec6694f058615be83e", null ],
    [ "nnz", "structdCOOmat.html#aa165c73f6701cd01aafc0868e6261dfe", null ],
    [ "row", "structdCOOmat.html#a741a152c7b18c401af249dfb3a113c95", null ],
    [ "rowind", "structdCOOmat.html#a420000e526ebdd25685ab8af19388036", null ],
    [ "val", "structdCOOmat.html#a6e543bb0c5acc1b10ba8e2a72eb92b52", null ]
];