var structiCSRmat =
[
    [ "col", "structiCSRmat.html#a35e7c2cd24fb4171cce3d78cd8bb3a23", null ],
    [ "IA", "structiCSRmat.html#a82a122cbfe1b4c4d010a147a0a72ebd1", null ],
    [ "JA", "structiCSRmat.html#ab39d8b2fa3fbf92c115fa73cb98bc7ce", null ],
    [ "nnz", "structiCSRmat.html#aa165c73f6701cd01aafc0868e6261dfe", null ],
    [ "row", "structiCSRmat.html#a741a152c7b18c401af249dfb3a113c95", null ],
    [ "val", "structiCSRmat.html#acd6cc7c196f03f830a22bbba89a6876f", null ]
];