var searchData=
[
  ['x_0',['x',['../structAMG__data.html#abc14393d10a69508c5f56f85abd6670c',1,'AMG_data::x()'],['../structAMG__data__bsr.html#abc14393d10a69508c5f56f85abd6670c',1,'AMG_data_bsr::x()']]],
  ['xloc1_1',['xloc1',['../structSWZ__data.html#a6774a4ebc40deaf07352694a56300dca',1,'SWZ_data']]],
  ['xtrmumps_2ec_2',['XtrMumps.c',['../XtrMumps_8c.html',1,'']]],
  ['xtrpardiso_2ec_3',['XtrPardiso.c',['../XtrPardiso_8c.html',1,'']]],
  ['xtrsamg_2ec_4',['XtrSamg.c',['../XtrSamg_8c.html',1,'']]],
  ['xtrsuperlu_2ec_5',['XtrSuperlu.c',['../XtrSuperlu_8c.html',1,'']]],
  ['xtrumfpack_2ec_6',['XtrUmfpack.c',['../XtrUmfpack_8c.html',1,'']]]
];
