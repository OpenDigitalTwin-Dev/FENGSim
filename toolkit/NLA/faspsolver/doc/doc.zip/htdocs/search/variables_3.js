var searchData=
[
  ['data_0',['data',['../structprecond.html#a735984d41155bc1032e09bece8f8d66d',1,'precond::data()'],['../structmxv__matfree.html#a735984d41155bc1032e09bece8f8d66d',1,'mxv_matfree::data()']]],
  ['decoup_5ftype_1',['decoup_type',['../structITS__param.html#a8b4cf9cc775442d790564a395e0a4725',1,'ITS_param::decoup_type()'],['../structinput__param.html#a8b4cf9cc775442d790564a395e0a4725',1,'input_param::decoup_type()']]],
  ['diag_2',['diag',['../structdSTRmat.html#a781ad64f97cef4bc66d1e932b64cb030',1,'dSTRmat::diag()'],['../structprecond__diag__str.html#aa2ab1984071b37d6300f7ddcc97c68de',1,'precond_diag_str::diag()'],['../structprecond__diag__bsr.html#aa2ab1984071b37d6300f7ddcc97c68de',1,'precond_diag_bsr::diag()']]],
  ['diaginv_3',['diaginv',['../structprecond__data__str.html#ad2ff3f7d26a74c17af4a2965f0acd2f6',1,'precond_data_str::diaginv()'],['../structAMG__data__bsr.html#ae43b7003db0005dbd7fbe5d404accb79',1,'AMG_data_bsr::diaginv()']]],
  ['diaginv_5fss_4',['diaginv_SS',['../structAMG__data__bsr.html#a25d2704faa2380f06acd084f13d6cdbf',1,'AMG_data_bsr']]],
  ['diaginvs_5',['diaginvS',['../structprecond__data__str.html#ad4d5bc3fd9c8850ddc012cb8a4638213',1,'precond_data_str']]],
  ['dif_6',['dif',['../structdCSRLmat.html#abe359223493d44177442a883d5ae441e',1,'dCSRLmat']]],
  ['dlength_7',['dlength',['../BlaIO_8c.html#a2d3b2e8da692b1543b7e549102ed9fed',1,'BlaIO.c']]]
];
