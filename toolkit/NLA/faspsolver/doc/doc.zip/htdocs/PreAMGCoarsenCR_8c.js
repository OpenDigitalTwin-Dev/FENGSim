var PreAMGCoarsenCR_8c =
[
    [ "fasp_amg_coarsening_cr", "PreAMGCoarsenCR_8c.html#ae7aed2d8d0547f615a1dc8510c7dded2", null ]
];