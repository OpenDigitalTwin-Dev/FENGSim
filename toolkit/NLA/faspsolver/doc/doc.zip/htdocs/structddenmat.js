var structddenmat =
[
    [ "col", "structddenmat.html#a35e7c2cd24fb4171cce3d78cd8bb3a23", null ],
    [ "row", "structddenmat.html#a741a152c7b18c401af249dfb3a113c95", null ],
    [ "val", "structddenmat.html#a82cce3c9fdbe13b378376686e43de0f3", null ]
];