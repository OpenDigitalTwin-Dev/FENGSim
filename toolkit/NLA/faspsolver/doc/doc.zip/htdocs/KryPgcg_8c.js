var KryPgcg_8c =
[
    [ "fasp_solver_dcsr_pgcg", "KryPgcg_8c.html#a8cabcdc17d0ae838cdcc31ad0f292684", null ],
    [ "fasp_solver_pgcg", "KryPgcg_8c.html#a0381261c7c3861f6885d35fa31ac1e61", null ]
];