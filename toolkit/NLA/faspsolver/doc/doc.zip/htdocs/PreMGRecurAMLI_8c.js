var PreMGRecurAMLI_8c =
[
    [ "fasp_amg_amli_coef", "PreMGRecurAMLI_8c.html#a449284186f1df5fc62c71118fc3b6b8c", null ],
    [ "fasp_solver_amli", "PreMGRecurAMLI_8c.html#ab77e139e7804d8736d30741ae89e0499", null ],
    [ "fasp_solver_namli", "PreMGRecurAMLI_8c.html#a3e3c8e156b6fa8c4ac1bd2dcbae68609", null ],
    [ "fasp_solver_namli_bsr", "PreMGRecurAMLI_8c.html#a7c5b5fd900ecf9bdd4d1aff50a6ddf0c", null ]
];