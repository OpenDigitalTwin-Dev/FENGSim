var structdSTRmat =
[
    [ "diag", "structdSTRmat.html#a781ad64f97cef4bc66d1e932b64cb030", null ],
    [ "nband", "structdSTRmat.html#a63ef4bb24e301b2bafb4274271cbe5e1", null ],
    [ "nc", "structdSTRmat.html#a840f9c262c2132c2d9ce0c641101432f", null ],
    [ "ngrid", "structdSTRmat.html#a8232379a7cb4d7cbdaac2c5f212a5188", null ],
    [ "nx", "structdSTRmat.html#a20a6d041e524469748ceafb98a61b046", null ],
    [ "nxy", "structdSTRmat.html#a3704a4b7e2066732f6095977ca306ba7", null ],
    [ "ny", "structdSTRmat.html#a380dcd17a9cee3661286d497114c80ff", null ],
    [ "nz", "structdSTRmat.html#a97045cf41030990e7a5715761eac8b3c", null ],
    [ "offdiag", "structdSTRmat.html#ad9769afd89d479d98bb9843d08c7f0d9", null ],
    [ "offsets", "structdSTRmat.html#a18c718e8123868e8178fcc7ec9265f26", null ]
];