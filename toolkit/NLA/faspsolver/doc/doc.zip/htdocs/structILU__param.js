var structILU__param =
[
    [ "ILU_droptol", "structILU__param.html#a98c24505c01afe05fe4389f16a84ea73", null ],
    [ "ILU_lfil", "structILU__param.html#a0acf9f67e0ee65774534b25d987824d6", null ],
    [ "ILU_permtol", "structILU__param.html#aeadd62bfc8d57238fcde97ae14b35ffe", null ],
    [ "ILU_relax", "structILU__param.html#a18a8038212e6b62f7651dab319f16c16", null ],
    [ "ILU_type", "structILU__param.html#a8d76e6308491d63b4e8a720bfe444e6c", null ],
    [ "print_level", "structILU__param.html#a29a57f89daa78e58e74d262209e9cf77", null ]
];