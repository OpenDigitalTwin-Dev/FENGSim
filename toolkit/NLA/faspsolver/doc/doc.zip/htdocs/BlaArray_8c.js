var BlaArray_8c =
[
    [ "fasp_blas_darray_ax", "BlaArray_8c.html#ab364b79055ff450b0e247c81b6402bcf", null ],
    [ "fasp_blas_darray_axpby", "BlaArray_8c.html#a8f1e7c082df70227eba8197693dcaad1", null ],
    [ "fasp_blas_darray_axpy", "BlaArray_8c.html#abcaadc539e454199f97965c1ac68a5c3", null ],
    [ "fasp_blas_darray_axpy_nc2", "BlaArray_8c.html#aa1c286d026b63d668dc424fe84f3d324", null ],
    [ "fasp_blas_darray_axpy_nc3", "BlaArray_8c.html#a0ac152ae5c9599c27d861973ac355fe6", null ],
    [ "fasp_blas_darray_axpy_nc5", "BlaArray_8c.html#a8520e226e7c6f595af80bcdfaf69bac0", null ],
    [ "fasp_blas_darray_axpy_nc7", "BlaArray_8c.html#a63ea30a737bbce7e3c6f76dc3cae5c82", null ],
    [ "fasp_blas_darray_axpyz", "BlaArray_8c.html#a2f02f40dce2caba419479fae6db164e1", null ],
    [ "fasp_blas_darray_axpyz_nc2", "BlaArray_8c.html#aad7fcc653c1069ea20f470d46cadf9ab", null ],
    [ "fasp_blas_darray_axpyz_nc3", "BlaArray_8c.html#ab672f496550630789dac62dafe42582e", null ],
    [ "fasp_blas_darray_axpyz_nc5", "BlaArray_8c.html#ad6252194b82c2a60787f2b31c5e3f6f7", null ],
    [ "fasp_blas_darray_axpyz_nc7", "BlaArray_8c.html#aa174aaf8ed7f9e10557fa03956619ee3", null ],
    [ "fasp_blas_darray_dotprod", "BlaArray_8c.html#a0855e2aa41931ec43021badfe5a0a372", null ],
    [ "fasp_blas_darray_norm1", "BlaArray_8c.html#a4455214bd9465a1e08fac8fe76e5bb8d", null ],
    [ "fasp_blas_darray_norm2", "BlaArray_8c.html#ab00a2869185b69e3396d896e45971cdc", null ],
    [ "fasp_blas_darray_norminf", "BlaArray_8c.html#a15075c9cae2811e6eb73af42acb7679a", null ]
];