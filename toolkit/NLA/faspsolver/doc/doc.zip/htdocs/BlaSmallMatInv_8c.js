var BlaSmallMatInv_8c =
[
    [ "SWAP", "BlaSmallMatInv_8c.html#aac9153aee4bdb92701df902e06a74eb3", null ],
    [ "fasp_smat_identity", "BlaSmallMatInv_8c.html#affc43ed3740bc68b8244768d4d408423", null ],
    [ "fasp_smat_identity_nc2", "BlaSmallMatInv_8c.html#aef3066d4d6bf4424ae19adf212082c35", null ],
    [ "fasp_smat_identity_nc3", "BlaSmallMatInv_8c.html#a8f15df4ff38748a5c3f96d30c1b3bd5f", null ],
    [ "fasp_smat_identity_nc5", "BlaSmallMatInv_8c.html#af7adf8914fd48943755a0bb889b2857b", null ],
    [ "fasp_smat_identity_nc7", "BlaSmallMatInv_8c.html#a584249c0174420c265b587e0e1fee004", null ],
    [ "fasp_smat_inv", "BlaSmallMatInv_8c.html#aec1d9b854f60e90059888d6364b795f9", null ],
    [ "fasp_smat_inv_nc", "BlaSmallMatInv_8c.html#a31b8da00a4a0593bf843ab021834ef00", null ],
    [ "fasp_smat_inv_nc2", "BlaSmallMatInv_8c.html#ad0698428c1cc203fbeec758bfcd028eb", null ],
    [ "fasp_smat_inv_nc3", "BlaSmallMatInv_8c.html#a50d5ef97e8994c1cd63b0bc1e12659ce", null ],
    [ "fasp_smat_inv_nc4", "BlaSmallMatInv_8c.html#a6200da4a97c680c72cec9728371b01ae", null ],
    [ "fasp_smat_inv_nc5", "BlaSmallMatInv_8c.html#af0ae05788951def7a8dc1d591b6eac8f", null ],
    [ "fasp_smat_inv_nc7", "BlaSmallMatInv_8c.html#ac5e9104860ef9eaa670ce7b776704d39", null ],
    [ "fasp_smat_invp_nc", "BlaSmallMatInv_8c.html#a94f5eb35bd98284530d7f6b6f62d76f2", null ],
    [ "fasp_smat_Linf", "BlaSmallMatInv_8c.html#a19aee9d3f42e4e9f146ca71afe9f610b", null ]
];