var AuxArray_8c =
[
    [ "fasp_darray_cp", "AuxArray_8c.html#aa61d9ea10ede1a39edc1f20590736cbf", null ],
    [ "fasp_darray_set", "AuxArray_8c.html#a2e9983c150a380febdfa36bffe4bfa48", null ],
    [ "fasp_iarray_cp", "AuxArray_8c.html#acb2468dd91ea7b09328a54ea65ab6f1c", null ],
    [ "fasp_iarray_set", "AuxArray_8c.html#a4b55dc565293f1d69bcbc13a8c44f75d", null ]
];