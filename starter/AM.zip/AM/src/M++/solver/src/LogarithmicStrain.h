double* LGStrain (double* tensor);
double* LGStrain2 (double* tensor, int fun=0);
double* ExpStrain2 (double* tensor);
double* NStrain (double* tensor);

