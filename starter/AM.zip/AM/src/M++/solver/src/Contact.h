bool SegmentIntersection (double* x);		

